---
layout: default
title: "关于：About"
---

## 个人简介：

* 欧阳利平
* Web后台开发、Android应用开发爱好者
* 来自江西 现居广州

## 联系方式

<p class="contact">
 <a href="http://weibo.com/ouyanglip" title="微博联系我"><img src="http://www.sinaimg.cn/blog/developer/wiki/LOGO_32x32.png" width="24" height="24" style="display:inline-block;vertical-align:middle"></a><br/>
        <a href="http://www.zhihu.com/people/lippi-ouyang" title="知乎联系我"><img src="http://www.zhihu.com/favicon.ico" width="24" height="24" style="display:inline-block;vertical-align:middle"></a><br/>
 <a href="https://github.com/LippiOuYang" title="Github联系我"><img src="http://www.github.com/favicon.ico" width="24" height="24" style="display:inline-block;vertical-align:middle"></a><br/>
邮箱: ouyanglip@gmail.com 
</p>

### 关于本站：

* 搭建于[Github](https://github.com/LippiOuYang/LippiOuYang.github.io),欢迎Fork
* 模板及样式来源[Useful Paradigm](http://usefulparadigm.com/)
* 折腾开始于2014年6月1日，基本在2014年6月15日完工。

## 其他流言
* 未**女昏**人士；
* 阿森纳球迷；
* 实况足球忠实粉丝；
