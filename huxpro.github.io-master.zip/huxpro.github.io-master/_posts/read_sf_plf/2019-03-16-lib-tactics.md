---
title: "「软件基础 - PLF」 16. A Collection of Handy General-Purpose Tactics"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - 软件基础 SF
  - Coq
  - 笔记
---

TBD
