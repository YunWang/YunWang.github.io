---
title: "「软件基础 - PLF」 4. Hoare Logic as a Logic"
layout: post
author: "Hux"
header-style: text
hidden: true
tags:
  - 软件基础 SF
  - Coq
  - 笔记
---

TBD
